### [Switching Config Profiles](accent://)

This is used for when you have 2 Config Profiles installed and want to switch between them.

### [Part [1/1] Switching Config Profiles](accent://)

1. Enable Airplane Mode
2. Switch Config Profile in DNS Settings
3. You can delete any unused Config Profiles after it is switched
4. Disable Airplane Mode
