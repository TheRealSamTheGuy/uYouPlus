## [Certificate Status](accent://)

### [Continent:](accent://)

**Permissions**:

Push Notifications: 🟢

**Expiration**: 

13/06/2025: ✅

### [NetworkTech:](accent://)

**Permissions**:

Push Notifications: 🟢

**Expiration**:

12/03/2025: ✅

### [Sunshine 1:](accent://)

**Permissions**:

Push Notifications: 🟢

**Expiration**: 

13/09/2025: ✅

### [Sunshine 2:](accent://)

**Permissions**:

Push Notifications: 🟢

**Expiration**: 

6/06/2025: ✅

### [Sunshine 3:](accent://)

**Permissions**:

Push Notifications: 🔴

**Expiration**:

05/06/2025: ✅ 

### [SunLife:](accent://)

**Permissions**:

Push Notifications: 🔴

**Expiration**:

27/03/2025: ✅
