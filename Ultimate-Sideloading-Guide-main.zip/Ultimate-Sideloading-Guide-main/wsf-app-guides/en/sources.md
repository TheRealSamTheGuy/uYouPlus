## [Sources](accent://)

Sources are available in the Discord Server, in the #FAQ channel!
