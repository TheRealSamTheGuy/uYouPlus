### [Continent:](accent://)
**Berechtigungen**:

Push Benachrichtigungen: 🟢

**Ablauf**: 

13/06/2025: ✅

### [NetworkTech:](accent://)
**Berechtigungen**:

Push Benachrichtigungen: 🟢

**Ablauf**:

12/03/2025: ✅

### [Sunshine 1:](accent://)
**Berechtigungen**:

Push Benachrichtigungen: 🟢

**Ablauf**: 

13/09/2025: ✅

### [Sunshine 2:](accent://)
**Berechtigungen**:

Push Benachrichtigungen: 🟢

**Ablauf**: 

6/06/2025: ✅

### [Sunshine 3:](accent://)
**Berechtigungen**:

Push Benachrichtigungen: 🔴

**Ablauf**:

05/06/2025: ✅ 

### [SunLife:](accent://)
**Berechtigungen**:

Push Benachrichtigungen: 🔴

**Ablauf**:

27/03/2025: ✅
