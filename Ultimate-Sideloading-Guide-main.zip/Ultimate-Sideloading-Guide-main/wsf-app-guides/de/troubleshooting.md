- Unverifiziert?

- Crashende Apps? 

- App nicht verfügbar? 

- Integrität konnte nicht überprüft werden? 

Du musst der "Revoked" Guide folgen!

### [Konfigurationsprofil verschwunden?](accent://)

Du hast warscheinlich entweder Cowabunga oder Nugget nach der Installation verwendet, diese Tools stören das Profil und könnten dazu führen das es verschwindet.

Du musst dein Gerät zurücksetzen oder von einem älteren Backup wiederherstellen, welches du gemacht hast vor der Nutzung der Tools
