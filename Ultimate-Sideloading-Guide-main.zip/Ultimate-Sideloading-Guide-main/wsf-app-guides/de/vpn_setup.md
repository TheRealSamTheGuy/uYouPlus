Kleiner Hinweis: Die meisten kostenlosen VPNs funktionieren hiermit nicht, du musst rausfinden welchen Typ von DNS deine VPN unterstützt und diese unten ersetzen.

### [Teil [1/1] Nutzung von VPNs](accent://)
1. Finde die DNS Einstellung deiner VPN und ersetze sie mit den folgenden Informationen:


#### [madNS Config Profile:](accent://)
DNS Server:

45.90.28.21

45.90.30.21

DNS über HTTPS:

https://dns.nextdns.io/8bf6c6

#### [madNS Config Profile + Update Blocker:](accent://)
DNS Server:

45.90.28.210

45.90.30.210

DNS über HTTPS:

https://dns.nextdns.io/595d8c

#### [madNS Config Profile + Ad-Blocker:](accent://)
DNS Server:

45.90.28.104

45.90.30.104

DNS über HTTPS:

https://dns.nextdns.io/335179

#### [madNS Config Profile + Update Blocker + Ad-Blocker:](accent://)
DNS Server:

45.90.28.239

45.90.30.239

DNS über HTTPS:

https://dns.nextdns.io/828ff2
