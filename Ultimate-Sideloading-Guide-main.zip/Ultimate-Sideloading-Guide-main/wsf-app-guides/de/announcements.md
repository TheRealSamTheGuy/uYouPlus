madNS is now available, Make sure to follow the VPN guide!

madNS is compatible with VPNs, Feather and ChatGPT!

Guides for other sideloaders will be available soon!

-wsf
