Wenn du Konfigurationsprofile wechseln möchtest befolge diese Guide

### [Teil [1/1] Wechseln der Konfigurationsprofile](accent://)
1. Schalte Flugmodus an
2. Wechsel das Konfigurationsprofil in den DNS Einstellungen
3. Schalte Flugmodus aus