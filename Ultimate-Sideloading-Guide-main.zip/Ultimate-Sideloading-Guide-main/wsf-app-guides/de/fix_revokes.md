Methode 1 funktioniert oft und du musst deine Daten nicht löschen
bei Methode 2 musst du deine Daten löschen und kannst keine Backups nutzen

### Methode 1
1. Entferne das Konfigurationsprofil und alle von WSF installierten Apps
2. Mache ein Backup deines Geräts mit iTunes oder Finder
3. Nach dem Backup setze dein iOS Gerät MIT ITUNES ODER FINDER zurück
4. Stelle dein Backup wiederher
5. Befolge die Guide erneut

### Methode 2
1. Entferne das Konfigurationsprofil und alle von WSF installierten Apps
2. Setze dein iOS Gerät MIT ITUNES ODER FINDER zurück
3. Befolge die Guide erneut

