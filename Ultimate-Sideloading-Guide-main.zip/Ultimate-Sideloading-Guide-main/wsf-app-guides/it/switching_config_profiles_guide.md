## [Switching Config Profiles](accent://)  

Questo metodo viene utilizzato quando desideri passare da un Config Profile a un altro e viceversa.  

### [Part [1/1] Switching Config Profiles](accent://)  
1. Abilita la Modalità Aereo  
2. Cambia il Config Profile nelle Impostazioni DNS  
3. Puoi eliminare i Config Profiles non utilizzati dopo il cambio  
4. Disabilita la Modalità Aereo