### [WSF Config Profile](accent://)  
Non supporta VPN, Feather e ChatGPT.  

### [madNS Config Profile](accent://)  
Supporta VPN, Feather e ChatGPT.  

### [What does Update Blocker or Ad-Blocker mean?](accent://)  
Update Blocker: Blocca gli aggiornamenti OTA di Apple  

Ad-Blocker: Blocca la maggior parte delle pubblicità online e dei tracker  

Assicurati di non avere alcun VPN attivato durante l'installazione, anche se utilizzi il madNS Config Profile, poiché dovrai configurarlo successivamente seguendo la guida VPN.  

## [Installing the Config Profile](accent://)  
1. Vai alla scheda download e seleziona il Config Profile che desideri installare in base alle tue esigenze.  

2. Clicca su Download, e il profilo verrà importato automaticamente nelle impostazioni.  

3. Ora, apri le impostazioni e vai su Generali > VPN e gestione dispositivi e installa il profilo scaricato.  

4. Il profilo verrà abilitato automaticamente.  

5. Se stai utilizzando il madNS Config Profile e vuoi usare un VPN insieme, assicurati di seguire la guida VPN.  

6. Ora puoi procedere all'installazione di qualsiasi sideloader.  