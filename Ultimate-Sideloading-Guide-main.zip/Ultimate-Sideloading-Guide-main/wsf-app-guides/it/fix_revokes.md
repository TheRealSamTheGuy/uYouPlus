Il metodo 1 ha un tasso di successo molto alto e non cancellerà i tuoi dati.

Il metodo 2 funzionerà sicuramente, ma cancellerà i tuoi dati.

Non devi utilizzare alcun backup con il Metodo 2.

### [Method 1](accent://)
1. Rimuovi il profilo di configurazione e disinstalla tutte le app che hai installato.  
2. Effettua un backup del tuo dispositivo utilizzando iTunes o Finder.  
3. Dopo aver completato il backup, ripristina il dispositivo in modalità Recovery o in modalità DFU.  
5. Se hai un backup iCloud, dopo aver effettuato l'accesso con il tuo ID Apple, ti verrà richiesto di ripristinare il backup. Se hai un backup locale, collega il telefono, apri Finder (su macOS) o iTunes (su Windows) e seleziona "Ripristina backup" dal menu del dispositivo.  
6. Segui nuovamente la guida partendo dall'installazione del profilo di configurazione.  

### [Method 2](accent://)
1. Rimuovi il profilo di configurazione e disinstalla tutte le app che hai installato.  
2. Ripristina il dispositivo utilizzando la modalità Recovery o la modalità DFU.  
6. Segui nuovamente la guida partendo dall'installazione del profilo di configurazione.  