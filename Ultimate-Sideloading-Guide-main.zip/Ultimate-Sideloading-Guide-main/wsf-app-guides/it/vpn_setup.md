## Using di VPNs  

Nota che la maggior parte delle VPN gratuite non funzionerà con questo metodo e dovrai scoprire quale tipo di DNS supporta la tua VPN e sostituirli con i valori riportati di seguito.  

### [Part [1/1] Using VPNs](accent://)  

1. Trova le impostazioni DNS della tua VPN e sostituiscile con le seguenti informazioni fornite.  

#### [madNS Config Profile:](accent://)  

Server DNS:  

45.90.28.21  

45.90.30.21  

DNS over HTTPS:  

https://dns.nextdns.io/8bf6c6  

#### [madNS Config Profile + Update Blocker:](accent://)  

Server DNS:  

45.90.28.210  

45.90.30.210  

DNS over HTTPS:  

https://dns.nextdns.io/595d8c  

#### [madNS Config Profile + Ad-Blocker:](accent://)  

Server DNS:  

45.90.28.104  

45.90.30.104  

DNS over HTTPS:  

https://dns.nextdns.io/335179  

#### [madNS Config Profile + Update Blocker + Ad-Blocker:](accent://)  

Server DNS:  

45.90.28.239  

45.90.30.239  

DNS over HTTPS:  

https://dns.nextdns.io/828ff2  
