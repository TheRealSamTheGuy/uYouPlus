## [Post Install Notes](accent://)  

- Non devi mai disabilitare il Config Profile!  

- Attiva la Modalità Aereo se stai passando a un altro Config Profile!  

- Non utilizzare Nugget o Cowabunga, altrimenti il Config Profile potrebbe sparire e potrebbe non funzionare! Usa la soluzione alternativa nella sezione Miscellaneous!  

- Non puoi utilizzare un VPN a meno che tu non stia usando il madNS Config Profile, per il quale devi seguire la guida VPN nella sezione Miscellaneous!  

- Alcuni utenti hanno notato che, su dispositivi più vecchi, le app potrebbero essere revocate durante il riavvio! Disattiva il WiFi e abilita la Modalità Aereo se desideri riavviare!  

- Controlla periodicamente gli aggiornamenti, gli annunci e le informazioni sui certificati nel Portal!  

Non seguire le linee guida sopra riportate causerà la revoca delle tue app!  
