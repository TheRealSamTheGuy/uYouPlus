## [Revoked](accent://)  

- Non verificato?  

- App che crashano?  

- L'app non è disponibile?  

- L'integrità non può essere verificata?  

Devi seguire la Guida per i certificati revocati, oppure puoi provare altri link di download!  

## [Config Profile Disappeared?](accent://)  

Devi aver utilizzato Cowabunga o Nugget dopo l'installazione, questi strumenti interferiscono con la guida e causano la scomparsa dei Config Profiles.  

Dovrai ripristinare completamente il tuo dispositivo o ripristinare da un backup precedente in cui non hai utilizzato questi strumenti.
