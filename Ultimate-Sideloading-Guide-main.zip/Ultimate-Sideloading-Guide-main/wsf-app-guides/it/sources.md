## [Sources](accent://)  

Le sorgenti sono disponibili nel server Discord, nel canale #FAQ!