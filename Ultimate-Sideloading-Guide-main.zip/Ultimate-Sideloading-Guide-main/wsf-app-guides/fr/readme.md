## The french guide is currently in the works by @RonanACNH (https://twitter.com/RonanACNH) and will be available soon
