## [Post Install Notes](accent://)

- You must never disable the Config Profile!

- Go into Airplane Mode if you're switching to another Config Profile!

- Don't use Nugget or Cowabunga otherwise the Config Profile will disappear and possibly not work! Use the workaround in Miscellaneous section!

- You cannot use a VPN unless you're using the madNS Config Profile for which you need to follow the VPN Guide in the Miscellaneous section!

- Some users have found that on older devices, your apps might revoke when restarting! Disable WiFi and enable Airplane Mode when wanting to restart!

- Check for Updates, Announcements and Certificate Information in Portal periodically!

Not following the guidelines above will cause your apps to be revoked!
