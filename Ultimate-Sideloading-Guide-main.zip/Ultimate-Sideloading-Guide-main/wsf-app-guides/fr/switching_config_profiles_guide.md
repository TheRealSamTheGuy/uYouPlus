## [Switching Config Profiles](accent://)

This is used for when you want to switch Config Profiles from one to another and vice versa

### [Part [1/1] Switching Config Profiles](accent://)
1. Enable Airplane Mode
2. Switch Config Profile in DNS Settings
3. You can delete any unused Config Profiles after it is switched
4. Disable Airplane Mode
