### [Announcements](accent://)

READ VPN SETUP GUIDE!!!

Join Discord!

https://discord.gg/wsf

