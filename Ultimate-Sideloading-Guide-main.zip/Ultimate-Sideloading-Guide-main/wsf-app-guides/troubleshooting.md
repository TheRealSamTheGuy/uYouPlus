### [Revoked](accent://)

- Unverified?

- Crashing Apps? 

- App is not available? 

- Integrity could not be verified? 

You need to follow the Revoked Guide, or alternatively you can try other download links!

## [Config Profile Disappeared?](accent://)

You must have either used Cowabunga or Nugget after your installation, Those tools intefere with the guide and cause Config Profiles to go missing.

You will need to reset your entire device or restore from an older backup in which you have not used those tools.
